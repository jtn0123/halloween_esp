# V3.4 Integrated — DFM REVIEW ONLY — NOT RELEASED

Review this package before quoting or releasing manufacture. It is not an approved assembly order. Board outline: 100 × 80 mm; 4 copper layers; nominal board thickness 1.6 mm. Native stackup, Gerber layer attributes and drill files are authoritative; supplier must confirm its actual stackup/material/process. Do not assume a controlled-impedance specification.


## Selected fabrication finish

Keep ENIG with 1 microinch gold for this Integrated batch. Use four-layer 1.6 mm FR-4 TG135, 1 oz outer / 0.5 oz inner copper. Retain the 16 specified filled/capped thermal holes. JLC Standard assembly and X-ray apply to the selected N16R8 module. The batch is five PCBs: two assembled and three bare. HASL or OSP substitution requires a separate process decision. ENIG is the selected assembly process, not an electrically mandatory feature.

## Filled and capped holes

Apply **epoxy filling, planarization and copper capping** to exactly the 16 plated 0.30 mm thermal holes in `filled-capped-holes.csv`, highlighted on `thermal-hole-map.png`. Feather has four MAX98357A exposed-pad vias. Integrated has four amplifier exposed-pad vias plus twelve ESP32 module exposed-pad holes. Do not fill component lead holes, socket holes, connector holes or mounting holes. Ordinary routing vias do not require this special process. Confirm the map against CAM before production.

The CSV uses native KiCad absolute millimetres: board upper-left is X=60,Y=40 and Y increases downward. The Gerber/Excellon exports use the CAD absolute origin and can present Y with the opposite sign. These coordinates are review aids, not a machine program. Match hole locations and drill diameters to the actual layers before applying the process.

Do not substitute open, merely tented, or ink-plugged holes under these exposed pads without an approved redesign and assembly-process review. Keep the thermal connection to GND. Ask for the filled/capped process surcharge explicitly; no price saving or vendor acceptance is claimed.

## Stereo assembly

R29 must be 100 kohm (Yageo RC0603FR-07100KL, U6 LEFT); R30 must be 374 kohm (RC0603FR-07374KL, U7 RIGHT). Both are 0603, 1%, 0.1 W, 100 ppm/C. Do not fit the older 1 Mohm mono selectors. The new direct-mounted IC circuit differs from the breakout modules on printed v3.3a. Use the matching variant stereo firmware overlay.

## Assembly review

Review exact BOM MPNs, footprint compatibility, orientation, paste aperture and stencil design, exposed-pad solder coverage and voiding, the filled/capped surface, and soldermask webs. Paste layers are CAD inputs requiring assembler review, not a validated stencil recipe. `placement-review.csv` is a reference placement list, not a machine-ready pick-and-place file. BOM sourcing/stock and substitution approvals remain open. Follow the variant's ASSEMBLY-NOTES.md.

The board has passed local CAD checks; no powered, thermal, RF, assembly-yield, USB fit or enclosure test has been performed. Do not release fabrication until the supplier review and intended assembly choices are accepted. No supplier has received this package.

## Sources

- MAX98357A exposed-pad grounding/thermal requirements: https://www.analog.com/media/en/technical-documentation/data-sheets/max98357a-max98357b.pdf
- ESP32-S3 layout/thermal guidance: https://docs.espressif.com/projects/esp-hardware-design-guidelines/en/latest/esp32s3/pcb-layout-design.html
- Via process terminology and supplier limitations: https://jlcpcb.com/help/article/pcb-via-covering
