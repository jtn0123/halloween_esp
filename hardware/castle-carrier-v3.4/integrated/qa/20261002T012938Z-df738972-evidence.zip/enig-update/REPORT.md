# Integrated ENIG and assembly-instruction update — 2026-10-01

ENIG with 1 microinch gold is retained for the Integrated prototype batch, as requested. All 16 specified epoxy-filled, planarized, copper-capped thermal holes remain. Use four layers, nominal 1.6 mm FR-4 TG135, 1 oz outer / 0.5 oz inner copper, JLC Standard assembly and X-ray; five PCBs, two assembled and three bare. Final red/black color remains an order choice. ENIG was already included in the September 30 quote, so this update does not add a new quoted charge or establish a delivered price.

## Corrections

- Native finish metadata and the Integrated generator agree on ENIG; copper, pads, holes, mask, paste, placement and routing are unchanged.
- Current assembly requirements specify N16R8, 16 MB flash / 8 MB octal PSRAM and SD GPIO39/40/41, not the inherited N4R2 settings.
- U1/U4 vias are described as off-pad. Only the mapped 12 module holes and four amplifier holes receive the fill/cap process.
- R1–R11 are correctly described as surface-mount. Stereo selectors remain 100 kohm LEFT / 374 kohm RIGHT.
- The old step-back report's full-paste-opening statement was corrected against both variants' saved geometry: each amplifier has four 0.6 mm square windows over a 1.5 mm square exposed pad, or 64% nominal coverage. Historical screenshots and original audit inputs remain identified as the earlier snapshot.
- The Integrated Gerber job, instructions, file manifest and review ZIP were refreshed. The package generator can now refresh just one variant. The QA gate checks native/Gerber finish agreement and includes current Integrated assembly requirements in its input hashes.

## Verification

Before-copy backups and the confirmed mismatches are in `before/` and `before-check.json`. Targeted checks pass: generator ENIG, exported ENIG, corrected module/memory/process instructions, and protected Feather source/manufacturing hashes. Fresh required QA passes for both variants: DRC/ERC/parity/unrouted checks are clean, manufacturing exports match, and native/Gerber finish agreement passes. The 13 copper/mask/paste/outline/drill geometry exports also match the before-copy after removing creation timestamps. Receipt: [`20261002T012938Z-df738972`](../../qa/runs/20261002T012938Z-df738972/receipt.json). Details are in [update-check.json](update-check.json). Firmware compilation provenance was reverified; firmware was not rebuilt or flashed.

Supplier acceptance of CAM, exact thermal-hole treatment, stencil/reflow and orientation remains open. No order, upload, powered test, firmware change or fabrication release was performed. The old JLC quote artifacts remain historical evidence of the unchanged ENIG configuration.
