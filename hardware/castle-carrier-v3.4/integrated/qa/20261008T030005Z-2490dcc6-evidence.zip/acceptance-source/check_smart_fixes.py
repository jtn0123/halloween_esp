"""Independent regression acceptance for audit findings D1-D5.
Source/configuration and static CAD checks only; never physical qualification.
"""
from pathlib import Path
import hashlib,json,re,heapq,math,sys
import os
from hardware_scope import integrated_errors, negative_controls
ROOT=Path(os.environ.get("CASTLE_QA_WORK", Path(__file__).resolve().parents[1]))
AUD=ROOT/'audits/06-smart-fixes'
def firmware_errors(cpp,defs,name):
 e=[]
 for codec in ['MP3','WAV','OPUS']:
  if '#define USE_AUDIO_'+codec+'_SUPPORT' not in defs:e.append(codec+' decoder absent')
 for item in ['castle_rate_safe_speaker->set_target_sample_rate(44100)',
              'castle_rate_safe_speaker->set_target_bits_per_sample(16)',
              'castle_rate_safe_speaker->set_output_speaker(castle_speaker)',
              'castle_media->set_announcement_speaker(castle_rate_safe_speaker)',
              'I2S_SLOT_MODE_STEREO','I2S_STD_SLOT_BOTH',
              'App.pre_setup("castle-v34-'+name+'"']:
  if item not in cpp:e.append('Missing '+item)
 return e
def path_length(data,start,end):
 graph={}
 def key(q):return tuple(round(x,5) for x in q)
 for t in data['segments']:
  a,z=key(t['start_mm']),key(t['end_mm'])
  graph.setdefault(a,[]).append((t['length_mm'],z));graph.setdefault(z,[]).append((t['length_mm'],a))
 queue=[(0,key(start))];seen=set()
 while queue:
  dist,node=heapq.heappop(queue)
  if node==key(end):return dist
  if node in seen:continue
  seen.add(node)
  for d,n in graph.get(node,[]):heapq.heappush(queue,(dist+d,n))
 raise AssertionError('No copper path')
def power_errors(fps):
 e=[]
 for ref,val in [('U9','TPS73701DCQRM3'),('U10','LM66100DCKR')]:
  if fps.get(ref,{}).get('value')!=val:e.append('Wrong '+ref)
 for ref,pins in {'U10':{'1':'FEATHER_PREBAT','2':'GND','3':'FEATHER_BAT','5':'GND','6':'FEATHER_BAT'},'C29':{'1':'FEATHER_PREBAT','2':'GND'}}.items():
  actual={p['number']:p['net'] for p in fps.get(ref,{}).get('pads',[])}
  for pad,net in pins.items():
   if actual.get(pad)!=net:e.append(ref+'.'+pad)
 if 'D8' in fps:e.append('Old Schottky still fitted')
 return e
if 'CASTLE_QA_RUN' not in os.environ:
 raise SystemExit('Run the fresh two-variant QA pipeline: bash validate.sh from the project root.')
geometry=json.loads((Path(os.environ['CASTLE_QA_RUN'])/'native-geometry.json').read_text())
oldgeo={name:geometry['before_'+name] for name in ['feather','integrated']}
results={}
for name in ['feather','integrated']:
 p=ROOT/name;src=p/'.tmp/firmware-build/src';cpp=(src/'main.cpp').read_text();defs=(src/'esphome/core/defines.h').read_text()
 e=firmware_errors(cpp,defs,name);controls=[]
 for codec in ['WAV','OPUS']:
  controls.append({'change':codec+' decoder removed','rejected':bool(firmware_errors(cpp,defs.replace('#define USE_AUDIO_'+codec+'_SUPPORT',''),name))})
 for old,new,label in [('set_target_sample_rate(44100)','set_target_sample_rate(24000)','unsupported output rate'),('set_announcement_speaker(castle_rate_safe_speaker)','set_announcement_speaker(castle_speaker)','resampler bypass'),('castle-v34-'+name,'castle-s3','duplicate legacy name')]:
  controls.append({'change':label,'rejected':bool(firmware_errors(cpp.replace(old,new),defs,name))})
 # Verify the actual compiled resampler forwards its target stream, not decoder rate.
 resampler=(src/'esphome/components/resampler/speaker/resampler_speaker.cpp').read_text()
 for fragment in ['this->target_sample_rate_','this->output_speaker_->set_audio_stream_info(this->target_stream_info_)']:
  if fragment not in resampler:e.append('Resampler implementation contract')
 build=json.loads((p/'out/firmware-build-check.json').read_text())
 if build['config_sha256']!=hashlib.sha256((p/'firmware-reference/castle_v34.yaml').read_bytes()).hexdigest():e.append('Stale firmware evidence')
 actual=geometry[name]['footprints'];before=oldgeo[name]['footprints']
 changed=[r for r in sorted(set(actual)|set(before)) if actual.get(r)!=before.get(r)]
 if name=='integrated':
  scoped_errors, changed_nets = integrated_errors(geometry[name], oldgeo[name])
  e += scoped_errors
  controls += negative_controls(geometry[name], oldgeo[name])
  power={'status':'USB_ROUTING_UPDATED_ONLY','changed_footprints':changed,'changed_copper_nets':changed_nets}
 else:
  e+=power_errors(actual)
  bad=json.loads(json.dumps(actual));bad['U10']['pads']=[{**q,'net':'GND'} if q['number']=='3' else q for q in bad['U10']['pads']]
  controls.append({'change':'ideal diode CE grounded instead of OUT','rejected':bool(power_errors(bad))})
  if set(changed)!={'U9','U10','D8','C28','C29'}:e.append('Unexpected Feather footprint change '+str(changed))
  def net_copper(net):
   return {'segments':sorted((tuple(sorted([tuple(q['start_mm']),tuple(q['end_mm'])])),q['width_mm'],q['layer']) for q in net['segments']),
           'vias':sorted((tuple(q['position_mm']),q['diameter_mm'],q['drill_mm']) for q in net['vias'])}
  changed_nets=[n for n in sorted(set(geometry[name]['nets'])|set(oldgeo[name]['nets'])) if net_copper(geometry[name]['nets'].get(n,{'segments':[],'vias':[]}))!=net_copper(oldgeo[name]['nets'].get(n,{'segments':[],'vias':[]}))]
  if set(changed_nets)-{'FEATHER_PREBAT','FEATHER_BAT','GND','PIR_OUT'}:e.append('Unexpected changed copper net '+str(changed_nets))
  pad=lambda r,num:next(q['position_mm'] for q in actual[r]['pads'] if q['number']==num)
  length=path_length(geometry[name]['nets']['FEATHER_PREBAT'],pad('U9','2'),pad('C28','1'))
  if length>=10:e.append('Output capacitor copper route >=10mm')
  # R33/R34 0.1%, 25 ppm/C, worst 65C offset from 25C.
  rt=.001+.000025*65;nom=1.204*(1+24900/10000)
  low=1.204*(1+24900*(1-rt)/(10000*(1+rt)))*.985
  high=1.204*(1+24900*(1+rt)/(10000*(1-rt)))*1.015
  # RON budget uses the 3.6V max as an engineering conservative proxy at 4.2V.
  # It is specified at -200mA; scaling it to 600mA is a model, not a component guarantee.
  bat_model=low-.6*.125-.02
  power={'status':'DESIGN_IMPROVED_BENCH_REQUIRED','changed_footprints':changed,
         'changed_copper_nets':changed_nets,
         'output_capacitor_route_mm':length,'prior_route_mm':28.190975,
         'nominal_U9_output_V':nom,'regulated_output_model_V':[low,high],
         'regulated_accuracy_model_requires_U9_input_V_min':round(high+.5,4),
         'BAT_model_at_600mA_V':bat_model,'assumed_trace_drop_V':.02,
         'ideal_diode_model_Ron_ohm':.125,
         'AP2112_drop_budget_V':bat_model-(3.3*1.015+.4),
         'RT9080_drop_budget_V':bat_model-(3.3*(1+.02+.01+.0035)+.53),
         'conditions':['No LiPo; USB and barrel transition test required.',
           'The 600mA calculation is a design model, not full-current/temperature qualification.',
           'Feather may use AP2112 or RT9080; identify the actual fitted regulator.',
           'Measure U9 input/output, BAT and 3.3V under intended full load; adapter tolerance and cable losses can invalidate the regulated-accuracy input condition.',
           'LM66100 comparator hysteresis/startup, reverse activation pulses and thermal behavior remain untested.'],
         'sources':['https://www.ti.com/lit/ds/symlink/tps737.pdf','https://www.ti.com/lit/ds/symlink/lm66100.pdf','https://www.richtek.com/assets/product_file/RT9080/DS9080-09.pdf']}
 r={'status':'PASS' if not e and all(c['rejected'] for c in controls) else 'FAIL','variant':name,'errors':e,'negative_controls':controls,'codecs':['MP3','WAV','OPUS'],'output_format':'44.1kHz / 16-bit / stereo','device_name':'castle-v34-'+name,'hardware':power,'physical_validation':'NOT_PERFORMED','compiled_resampler_sha256':hashlib.sha256(resampler.encode()).hexdigest()}
 (p/'out/smart-fix-check.json').write_text(json.dumps(r,indent=2)+'\n');results[name]=r
(Path(os.environ['CASTLE_QA_RUN'])/'smart-fix-closure.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2));assert all(r['status']=='PASS' for r in results.values())
