"""Two-variant QA with fresh checks and input/output receipts.

Receipts detect stale or damaged local evidence; they are not signed attestations.
No operation saves production CAD, regenerates its schematic, or flashes hardware.
"""
from pathlib import Path
import argparse, csv, datetime, fcntl, hashlib, json, os, re, shutil
from collections import Counter
import subprocess, sys, uuid

ROOT = Path(__file__).absolute().parents[1]
VARIANTS = ('feather', 'integrated')
CLI = Path(os.environ.get('CASTLE_KICAD_CLI', '/Volumes/512Flash/Applications/KiCad/KiCad.app/Contents/MacOS/kicad-cli'))
KPY = Path(os.environ.get('CASTLE_KICAD_PY', '/Volumes/512Flash/Applications/KiCad/KiCad.app/Contents/Frameworks/Python.framework/Versions/3.9/bin/python3'))
LIB = CLI.parent.parent/'SharedSupport'
APP = Path('/Users/justin/Documents/Github/halloween_esp')
REQUIRED = ('variant-check', 'netlist-review', 'sd-pullup-check', 'fabrication-policy-check',
            'audit-layout-check', 'fuse-bom-check', 'outline-check', 'stereo-check',
            'smart-fix-check', 'visual-audit-check')

class QAError(RuntimeError):
    pass

def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def write(path, data):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.new')
    temporary.write_text(json.dumps(data, indent=2) + '\n')
    temporary.replace(path)

def require(condition, message):
    if not condition:
        raise QAError(message)

def tree(path):
    # Ignore interpreter caches; never traverse symlink directory loops.
    return sorted(p for p in Path(path).rglob('*') if p.is_file()
                  and '__pycache__' not in p.parts and p.suffix != '.pyc')

def firmware_files(path):
    return {str(p.relative_to(path)): p for p in tree(path)
            if p.suffix in ('.yaml', '.h', '.cpp') and p.name != 'secrets.yaml'
            and '.esphome' not in p.parts}

def input_paths(root, app):
    paths = {}
    def add(p, key=None):
        require(p.is_file(), 'Missing checked input: ' + str(p))
        paths[key or str(p.relative_to(root))] = p
    for v in VARIANTS:
        p = root/v
        for name in ('castle-carrier.kicad_pcb', 'castle-carrier.kicad_sch',
                     'castle-carrier.kicad_pro', 'castle-carrier.kicad_dru',
                     'bom-v3.4-engineering.csv', 'fp-lib-table', 'sym-lib-table',
                     'castle.kicad_sym', 'README.md', 'ASSEMBLY-NOTES.md',
                     'validate.sh', 'rebuild.sh', 'out/DFM_REVIEW_NOT_RELEASED.zip',
                     'out/firmware-build-check.json'):
            add(p/name)
        for folder in ('gen', 'scripts', 'castle.pretty', 'models', 'firmware-reference', 'out/dfm-review'):
            for f in tree(p/folder): add(f)
        if v == 'feather': add(p/'out/usb-model-measurement.json')
        if v == 'integrated':
            add(p/'docs/ASSEMBLY-REQUIREMENTS.md')
            add(p/'docs/README.md')
        for f in tree(p/'.tmp/firmware-build/src'): add(f)
        for f in firmware_files(p/'.tmp/firmware-validation/firmware').values(): add(f)
        add(p/'.tmp/firmware-validation/audio/00_chirp.mp3')
        for name in ('firmware.elf', 'firmware.ota.bin', 'firmware.factory.bin'):
            found = list((p/'.tmp/firmware-build').rglob(name))
            require(len(found) == 1, f'{v}: ambiguous/missing compiled {name}')
            add(found[0])
    # Checked code only: GUI configuration and old shared build caches are outputs.
    for f in (root/'shared').iterdir():
        if f.is_file() and f.suffix in ('.py','.sh','.json'): add(f)
    for f in tree(root/'shared/qa_checks'): add(f)
    for v in VARIANTS:
        native=(root/v/'castle-carrier.kicad_pcb').read_text()
        for lib,name in re.findall(r'\(footprint "([^:"]+):([^"\n]+)"',native):
            stock=LIB/'footprints'/(lib+'.pretty')/(name+'.kicad_mod')
            if stock.is_file(): add(stock,'tool:footprint/'+lib+'/'+name)
    for name in ('README.md', 'REVIEW.md', 'VALIDATION.md', 'validate.sh',
                 'shared/reference/pre-stereo-20260929/v3.3a-design-hashes.json'):
        add(root/name)
    for v in VARIANTS:
        add(root/'audits/06-smart-fixes/before'/v/'castle-carrier.kicad_pcb')
    for f in tree(root/'stereo-bench'): add(f)
    old = root.parent/'castle-carrier-v3'
    for name in read(root/'shared/reference/pre-stereo-20260929/v3.3a-design-hashes.json'):
        add(old/name, 'legacy:'+name)
    for name in ('README.md', 'docs/WIRING.md', 'docs/AUDIO-CAPABILITY-v3.3a.md'):
        add(old/name, 'legacy:'+name)
    for name, f in firmware_files(app/'firmware').items(): add(f, 'application:firmware/'+name)
    add(app/'audio/00_chirp.mp3', 'application:audio/00_chirp.mp3')
    for label, p in [('kicad-cli', CLI), ('kicad-python', KPY), ('qa-python', Path(sys.executable))]:
        add(p, 'tool:'+label)
    for name in ('fp-lib-table', 'sym-lib-table'): add(LIB/'template'/name, 'tool:template/'+name)
    return paths

def capture(root, app):
    return {k: digest(p) for k, p in input_paths(root, app).items()}

def differences(expected, actual):
    return sorted(k for k in set(expected) | set(actual) if expected.get(k) != actual.get(k))

def verify_receipt(root=ROOT):
    state = read(root/'qa/latest.json')
    require(state.get('status') == 'PASS', 'Latest QA attempt did not pass; run bash validate.sh.')
    rel = Path(state['receipt'])
    require(not rel.is_absolute() and '..' not in rel.parts and rel.parts[:2] == ('qa', 'runs'), 'Invalid receipt path')
    receipt_path = root/rel
    require(digest(receipt_path) == state.get('receipt_sha256'), 'QA receipt changed; rerun validation.')
    receipt = read(receipt_path)
    require(receipt.get('schema') == 1 and receipt.get('status') == 'PASS', 'Invalid QA receipt')
    require(receipt.get('variants') == list(VARIANTS), 'Receipt must qualify both variants')
    changed = differences(receipt['inputs'], capture(root, Path(receipt['firmware_source'])))
    require(not changed, 'QA is stale. Changed inputs: ' + ', '.join(changed[:12]))
    for name, wanted in receipt['outputs'].items():
        rel = Path(name)
        require(not rel.is_absolute() and '..' not in rel.parts, 'Invalid output path')
        f = root/rel
        require(f.is_file() and digest(f) == wanted, 'QA evidence changed/missing: ' + name)
    return receipt

def firmware_check(root, app, run):
    reports = {}
    for v in VARIANTS:
        p = root/v; old = read(p/'out/firmware-build-check.json')
        require(old.get('status') == 'PASS', v+': no successful compile receipt')
        require(digest(p/'firmware-reference/castle_v34.yaml') == old['config_sha256'], v+': changed overlay; recompile')
        cached = firmware_files(p/'.tmp/firmware-validation/firmware')
        require({k: digest(f) for k, f in cached.items()} == old['firmware_source_files_sha256'], v+': cached compile inputs changed')
        current = firmware_files(app/'firmware')
        expected = {k: h for k, h in old['firmware_source_files_sha256'].items() if k not in ('build_path.yaml', 'castle_v34.yaml')}
        actual = {k: digest(f) for k, f in current.items() if k not in ('build_path.yaml', 'castle_v34.yaml')}
        require(actual == expected, v+': application inputs added/removed/changed; recompile: '+', '.join(differences(expected, actual)))
        require(digest(p/'.tmp/firmware-build/src/main.cpp') == old['main_cpp_sha256'], v+': generated C++ changed')
        for name, wanted in old['artifacts'].items():
            found = list((p/'.tmp/firmware-build').rglob(name))
            require(len(found) == 1 and digest(found[0]) == wanted, v+': compiled artifact changed: '+name)
        require(digest(app/'audio/00_chirp.mp3') == digest(p/'.tmp/firmware-validation/audio/00_chirp.mp3'), v+': embedded chirp changed; recompile')
        reports[v] = {'status': 'PASS', 'compile_generated_at': old['generated_at'],
                      'scope': 'Previous successful compilation reverified against current application/overlay, generated C++ and binaries; no new compile or physical playback.',
                      'application_source_files_checked': len(actual), 'artifacts': old['artifacts']}
    write(run/'firmware-provenance-check.json', reports)

def bom_and_rules(root, run):
    native = read(run/'native-manufacturing-inventory.json'); reports = {}
    for v in VARIANTS:
        p = root/v; rows = list(csv.DictReader((p/'bom-v3.4-engineering.csv').open()))
        fps = {f['reference']: f for f in native[v]['placements']}
        refs = [r['Reference'] for r in rows]
        require(len(refs) == len(set(refs)), v+': duplicate BOM reference')
        accessories = {'F1-CARTRIDGE'} | ({'U2-SOCKETS', 'USB-SERVICE-CABLE'} if v == 'feather' else set())
        require(set(refs) == {ref for ref in fps if not ref.startswith(('H', 'TP'))} | accessories, v+': BOM population differs from native PCB')
        for row in rows:
            ref = row['Reference']
            if ref in fps:
                require(row['Value / MPN'] == fps[ref]['value'], f'{v}: BOM/native value mismatch at {ref}')
                require(row['Footprint'].split(':')[-1] == fps[ref]['footprint'], f'{v}: BOM/native footprint mismatch at {ref}')
        byref = {r['Reference']: r for r in rows}
        for ref, value, mpn in [('R29', '100k', 'RC0603FR-07100KL'), ('R30', '374k', 'RC0603FR-07374KL')]:
            require(byref[ref]['Value / MPN'] == value and byref[ref]['Selected MPN'] == mpn, v+': stereo selector purchase mismatch at '+ref)
        require((p/'out/dfm-review/engineering-bom.csv').read_bytes() == (p/'bom-v3.4-engineering.csv').read_bytes(), v+': packaged BOM differs')
        rule = (p/'castle-carrier.kicad_dru').read_text()
        # An intentionally scoped 0.20 mm USB neck must not become a global exemption.
        code = '\n'.join(l for l in rule.splitlines() if not l.lstrip().startswith('#'))
        expected_rule = '''(version 1)
(rule "USB pair fan-out neck at J16"
 (constraint connection_width (min 0.20mm))
 (condition "A.NetName == 'USB_DP' || A.NetName == 'USB_DM'"))'''
        require(re.sub(r'\s+', '', code) == re.sub(r'\s+', '', expected_rule), v+': custom design rule differs from reviewed USB-only 0.20 mm policy')
        package=p/'out/dfm-review'; manifest=read(package/'package-manifest.json')
        require(manifest['native_pcb_sha256'] == digest(p/'castle-carrier.kicad_pcb'), v+': manufacturing native PCB hash differs')
        files={str(f.relative_to(package)):digest(f) for f in tree(package) if f.name!='package-manifest.json'}
        require(files == manifest['files'], v+': manufacturing package manifest mismatch')
        finish = re.search(r'\(copper_finish "([^"\n]+)"\)', (p/'castle-carrier.kicad_pcb').read_text())
        require(finish is not None, v+': native surface finish missing')
        job = read(package/'gerbers/castle-carrier-job.gbrjob')
        require(job['GeneralSpecs']['Finish'] == finish.group(1), v+': Gerber job surface finish differs from native PCB')
        if v == 'integrated':
            require(finish.group(1) == 'ENIG', 'Integrated: selected ENIG finish changed')
        reports[v] = {'status': 'PASS', 'native_BOM_rows_checked': len(fps)-sum(ref.startswith(('H', 'TP')) for ref in fps), 'custom_rules': 'USB_DP/USB_DM only; minimum connection width 0.20 mm', 'physical_validation': 'NOT_PERFORMED'}
        reports[v]['surface_finish'] = finish.group(1)
    write(run/'bom-and-custom-rule-check.json', reports)

def legacy_check(root, app, run):
    old = root.parent/'castle-carrier-v3'
    expected = read(root/'shared/reference/pre-stereo-20260929/v3.3a-design-hashes.json')
    require(all(digest(old/f) == h for f, h in expected.items()), 'Printed v3.3a native files changed')
    mono = (app/'firmware/castle_audio.yaml').read_text()
    require(re.search(r'channel:\s*mono\b', mono) and re.search(r'num_channels:\s*1\b', mono), 'Legacy mono profile changed')
    doc = old/'docs/AUDIO-CAPABILITY-v3.3a.md'
    require(doc.is_file(), 'Missing printed-board audio limitation documentation')
    fixture = read(root/'stereo-bench/fixture-check.json')
    require(fixture.get('status') == 'PASS' and digest(root/'stereo-bench/channel-identification.mp3') == fixture['mp3_sha256'], 'Stereo fixture changed; regenerate and decode/check it')
    result = {'status': 'PASS', 'native_files_sha256': expected, 'printed_board_policy': 'Dual mono; no hardware retrofit', 'shared_mono_source_sha256': digest(app/'firmware/castle_audio.yaml'), 'audio_documentation': str(doc), 'physical_playback': 'NOT_PERFORMED'}
    write(run/'legacy-preservation-check.json', result)
    write(run/'fixture-integrity-check.json', {'status': 'PASS', 'mp3_sha256': fixture['mp3_sha256'], 'scope': 'Reverified previously decoded fixture bytes; no physical playback'})

def execute(command, cwd, env, logs):
    r = subprocess.run([str(a) for a in command], cwd=cwd, env=env, capture_output=True, text=True, timeout=600)
    logs.append({'command': [str(a) for a in command], 'cwd': str(cwd), 'exit': r.returncode, 'stdout': r.stdout, 'stderr': r.stderr})
    require(r.returncode == 0, f'Check failed: {command}\n{r.stdout[-3000:]}\n{r.stderr[-3000:]}')

def fresh_checks(root, run, app):
    work = run/'work'; work.mkdir()
    logs = []; env = os.environ.copy(); env.pop('PYTHONOPTIMIZE', None)
    env.update(PYTHONDONTWRITEBYTECODE='1', CASTLE_QA_ROOT=str(root), CASTLE_QA_WORK=str(work), CASTLE_QA_RUN=str(run),
               KICAD10_SYMBOL_DIR=str(LIB/'symbols'), KICAD10_FOOTPRINT_DIR=str(LIB/'footprints'), KICAD10_3DMODEL_DIR=str(LIB/'3dmodels'))
    try:
        for v in VARIANTS:
            p = root/v; s = work/v; s.mkdir(); (s/'out').mkdir(); (s/'.tmp').mkdir()
            for name in ('castle-carrier.kicad_pcb', 'castle-carrier.kicad_sch', 'castle-carrier.kicad_pro', 'castle-carrier.kicad_dru',
                         'fp-lib-table', 'sym-lib-table', 'castle.kicad_sym', 'bom-v3.4-engineering.csv'):
                shutil.copy2(p/name, s/name)
            for name in ('gen', 'scripts', 'castle.pretty', 'models', 'firmware-reference'):
                shutil.copytree(p/name, s/name, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
            for name in ('firmware-build',): (s/'.tmp'/name).symlink_to(p/'.tmp'/name)
            shutil.copy2(p/'out/firmware-build-check.json', s/'out/firmware-build-check.json')
            if v == 'feather': shutil.copy2(p/'out/usb-model-measurement.json', s/'out/usb-model-measurement.json')
            before = work/'audits/06-smart-fixes/before'/v; before.mkdir(parents=True)
            shutil.copy2(root/'audits/06-smart-fixes/before'/v/'castle-carrier.kicad_pcb', before/'castle-carrier.kicad_pcb')
        (work/'shared').mkdir()
        shutil.copy2(root/'shared/check_stereo.py', work/'shared/check_stereo.py')
        execute([KPY, root/'shared/qa_checks/inspect_native.py'], work, env, logs)
        execute([KPY, root/'shared/qa_checks/read_native_manufacturing.py'], work, env, logs)
        firmware_check(root, app, run); bom_and_rules(root, run); legacy_check(root, app, run)
        for v in VARIANTS:
            print('Fresh CAD and circuit checks:', v, flush=True)
            s = work/v; config = s/'.tmp/kicad-config/10.0'; config.mkdir(parents=True)
            for name in ('fp-lib-table', 'sym-lib-table'): shutil.copy2(LIB/'template'/name, config/name)
            env.update(TMPDIR=str(s/'.tmp'), KICAD_CONFIG_HOME=str(config.parent))
            execute([sys.executable, s/'scripts/enforce_rules.py'], s, env, logs)
            execute([CLI, 'sch', 'erc', '--severity-all', '--exit-code-violations', '--format', 'json', '-o', s/'out/erc.json', s/'castle-carrier.kicad_sch'], s, env, logs)
            execute([CLI, 'sch', 'export', 'netlist', '--format', 'kicadsexpr', '-o', s/'out/castle-carrier.net', s/'castle-carrier.kicad_sch'], s, env, logs)
            execute([CLI, 'pcb', 'drc', '--refill-zones', '--save-board', '--schematic-parity', '--all-track-errors', '--severity-all', '--exit-code-violations', '--format', 'json', '-o', s/'out/drc.json', s/'castle-carrier.kicad_pcb'], s, env, logs)
            scripts = ['check_variant', 'check_v34', 'check_sd_pullups', 'check_fuse_bom']
            if v == 'integrated': scripts += ['check_audit_fixes', 'check_i2s_audit']
            if v == 'integrated': execute([KPY, root/'shared/qa_checks/check_usb_routes.py'], s, env, logs)
            for name in scripts: execute([sys.executable, s/'scripts'/(name+'.py')], s, env, logs)
            execute([sys.executable, work/'shared/check_stereo.py'], s, env, logs)
            for name in ('check_audit_layout', 'check_outline', 'check_visual_audit'):
                execute([KPY, s/'scripts'/(name+'.py')], s, env, logs)
            # Fresh exports use only the private refilled board, never source CAD.
            export = run/v; export.mkdir(); shutil.copy2(s/'out/drc.json', export/'drc.json')
            execute([CLI, 'pcb', 'export', 'gerbers', '--layers', 'F.Cu,In1.Cu,In2.Cu,B.Cu,F.Mask,B.Mask,F.Paste,B.Paste,F.Silkscreen,B.Silkscreen,Edge.Cuts', '-o', str(export/'gerbers')+'/', s/'castle-carrier.kicad_pcb'], s, env, logs)
            execute([CLI, 'pcb', 'export', 'drill', '--format', 'excellon', '--drill-origin', 'absolute', '--excellon-units', 'mm', '--excellon-separate-th', '-o', str(export/'drills')+'/', s/'castle-carrier.kicad_pcb'], s, env, logs)
        execute([sys.executable, root/'shared/check_smart_fixes.py'], work, env, logs)
        execute([sys.executable, root/'shared/qa_checks/compare_exports.py'], work, env, logs)
        execute([sys.executable, root/'shared/qa_checks/check_manufacturing_geometry.py'], work, env, logs)
        for v in VARIANTS:
            s=work/v
            for name in REQUIRED: require(read(work/v/'out'/(name+'.json')).get('status') == 'PASS', v+': '+name+' did not pass')
            d = read(work/v/'out/drc.json'); e = read(work/v/'out/erc.json')
            require(not any(d.get(k) for k in ('violations', 'unconnected_items', 'schematic_parity', 'ignored_checks')), v+': DRC has violations or exclusions')
            reviewed_defaults={'single_global_label','four_way_junction','simulation_model_issue','footprint_filter'}
            require({q['key'] for q in e.get('ignored_checks',[])} == reviewed_defaults and not any(s.get('violations') for s in e.get('sheets', [])), v+': ERC has violations or changed ignored categories')
            for name in ('filled-capped-holes.csv','placement-review.csv'):
                def rows(path):
                    with path.open(newline='') as f:
                        return Counter(tuple(sorted(row.items())) for row in csv.DictReader(f))
                require(rows(s/'out'/name) == rows(root/v/'out/dfm-review'/name), v+': native/manufacturing '+name+' mismatch')
    finally:
        write(run/'commands.json', logs)

def validate(root=ROOT, app=APP):
    qa = root/'qa'; qa.mkdir(exist_ok=True)
    with (qa/'.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        run_id = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'-'+uuid.uuid4().hex[:8]
        run = qa/'runs'/run_id; run.mkdir(parents=True)
        state = {'status': 'RUNNING', 'run': run_id, 'physical_validation': 'NOT_PERFORMED'}
        write(qa/'latest.json', state)
        try:
            before = capture(root, app)
            fresh_checks(root, run, app)
            changed = differences(before, capture(root, app))
            require(not changed, 'Inputs changed during validation: '+', '.join(changed[:12]))
            # Replace published acceptance evidence only after every stage passed.
            # Native sources, compiled caches and delivered manufacturing files stay intact.
            published = []
            for v in VARIANTS:
                for f in (run/'work'/v/'out').iterdir():
                    if f.is_file() and f.suffix in ('.json', '.net', '.csv'):
                        dest=root/v/'out'/f.name
                        shutil.copy2(f,dest); published.append(dest)
            require(not differences(before, capture(root, app)), 'Inputs changed during evidence publication')
            outputs = {str(f.relative_to(root)): digest(f) for f in tree(run)
                       if 'firmware-build' not in f.parts}
            outputs.update({str(f.relative_to(root)): digest(f) for f in published})
            receipt = {'schema': 1, 'status': 'PASS', 'run': run_id, 'variants': list(VARIANTS),
                       'generated_at': datetime.datetime.now().astimezone().isoformat(), 'firmware_source': str(app),
                       'inputs': before, 'outputs': outputs, 'work': str((run/'work').relative_to(root)),
                       'physical_validation': 'NOT_PERFORMED', 'firmware_scope': 'Previous compile reverified; no new compilation',
                       'scope': 'Fresh DRC/ERC/parity, circuit/power/layout/BOM/rules and manufacturing comparisons. Local integrity receipt, not adversarial attestation or fabrication release.'}
            write(run/'receipt.json', receipt)
            write(qa/'latest.json', {**state, 'status': 'PASS', 'receipt': str((run/'receipt.json').relative_to(root)), 'receipt_sha256': digest(run/'receipt.json')})
            verify_receipt(root)
            # Publish the report only after a complete two-variant receipt exists.
            result = subprocess.run([sys.executable, str(root/'shared/build_delivery_report.py')], cwd=root, capture_output=True, text=True, timeout=120)
            require(result.returncode == 0, 'Delivery report failed: '+result.stdout+result.stderr)
            print(result.stdout.strip(), flush=True)
        except Exception as exc:
            write(qa/'latest.json', {**state, 'status': 'FAIL', 'error': str(exc)})
            write(run/'failure.json', {'status': 'FAIL', 'error': str(exc)})
            raise
    return receipt

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('validate', 'verify'))
    parser.add_argument('--firmware-source', type=Path, default=APP)
    args = parser.parse_args()
    try:
        receipt = validate(app=args.firmware_source.absolute()) if args.command == 'validate' else verify_receipt()
        print('Both variants PASS; current receipt:', receipt['run'])
        print('Physical testing / fabrication release: NOT PERFORMED')
    except (QAError, OSError, ValueError, KeyError, subprocess.TimeoutExpired) as exc:
        print('QA REJECTED:', str(exc), file=sys.stderr)
        return 1
    return 0

if __name__ == '__main__':
    sys.exit(main())
