"""Bound the authorized Integrated change to front-layer USB segments only."""
import copy


def net_copper(net):
    return {
        'segments': sorted((tuple(sorted([tuple(q['start_mm']), tuple(q['end_mm'])])),
                            q['width_mm'], q['layer']) for q in net['segments']),
        'vias': sorted((tuple(q['position_mm']), q['diameter_mm'], q['drill_mm'])
                       for q in net['vias']),
    }


def integrated_errors(actual, before):
    errors = []
    if actual['footprints'] != before['footprints']:
        errors.append('Unexpected Integrated footprint/pad change')
    if actual['zones'] != before['zones']:
        errors.append('Unexpected Integrated zone declaration change')
    empty = {'segments': [], 'vias': []}
    changed = {name for name in set(actual['nets']) | set(before['nets'])
               if net_copper(actual['nets'].get(name, empty)) !=
               net_copper(before['nets'].get(name, empty))}
    if changed - {'USB_DP', 'USB_DM'}:
        errors.append('Unexpected Integrated non-USB copper change')
    for net in ('USB_DP', 'USB_DM'):
        current = actual['nets'].get(net, empty)
        if current['vias'] or any(t['layer'] != 'F.Cu' for t in current['segments']):
            errors.append('Integrated USB must stay front-only without vias')
    return errors, sorted(changed)


def negative_controls(actual, before):
    controls = []
    bad = copy.deepcopy(actual)
    ref = next(iter(bad['footprints']))
    bad['footprints'][ref]['position_mm'][0] += 1
    controls.append({'change': 'Integrated footprint moved',
                     'rejected': bool(integrated_errors(bad, before)[0])})
    bad = copy.deepcopy(actual)
    bad['nets']['+5V']['segments'][0]['width_mm'] /= 2
    controls.append({'change': 'Integrated power trace narrowed',
                     'rejected': bool(integrated_errors(bad, before)[0])})
    bad = copy.deepcopy(actual)
    bad['nets']['USB_DP']['vias'].append({'position_mm': [109.8, 80],
                                        'diameter_mm': .6, 'drill_mm': .3})
    controls.append({'change': 'Integrated USB via inserted',
                     'rejected': bool(integrated_errors(bad, before)[0])})
    return controls
